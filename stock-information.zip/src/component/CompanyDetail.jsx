import { NavLink } from "react-router-dom";
import "./company-summary.css";


export default function CompanyDetail({companyInfo}) {

    const formatMoney = (value) => {
        if (value >= 1_0000_0000_0000) {
            return `${(value / 1_0000_0000_0000).toFixed(1)}조`;
        }

        if (value >= 1_0000_0000) {
            return `${(value / 1_0000_0000).toFixed(1)}억`;
        }

        return value.toLocaleString();
    }

    console.log({companyInfo})
    let saleAmtSum = 0;
    for(let i=0; i< companyInfo.length; i++) {
        
        saleAmtSum =+ companyInfo[i].enpSaleAmt
    }


    let tastAmtSum = 0;
    for(let i=0; i< companyInfo.length; i++) {
        
        tastAmtSum =+ companyInfo[i].enpTastAmt
    }
    
    return(
        <div className="company-summary">
            <NavLink to="/test3" className="company-summary__back">
                ← 기업 재무 목록으로
            </NavLink>

            <div className="company-summary__grid">
                <div className="company-summary__metric">
                    <span>5년간 평균 기업매출 금액</span>
                    <strong>{formatMoney(saleAmtSum / 5)}</strong>
                </div>
                <div className="company-summary__metric">
                    <span>5년간 평균 기업총자산 금액</span>
                    <strong>{formatMoney(tastAmtSum / 5)}</strong>
                </div>
            </div>
        </div>
    )
}
